module.exports = async function handler(req, res) {

    if (req.method !== "POST") {
        return res.status(405).json({
            error: "Method not allowed"
        });
    }

    const API_KEY = process.env.GEMINI_API_KEY;

    if (!API_KEY) {
        return res.status(500).json({
            error: "AI configuration is missing."
        });
    }

    try {

        const contents = req.body.contents;

        if (!Array.isArray(contents) || contents.length === 0) {
            return res.status(400).json({
                error: "No messages received."
            });
        }

        const safeContents = contents
            .slice(-20)
            .filter(item =>
                ["user", "model"].includes(item.role) &&
                Array.isArray(item.parts)
            )
            .map(item => ({
                role: item.role,
                parts: item.parts
                    .filter(part =>
                        typeof part.text === "string"
                    )
                    .map(part => ({
                        text: part.text.slice(0, 5000)
                    }))
            }));

        if (!safeContents.length) {
            return res.status(400).json({
                error: "Invalid messages."
            });
        }

        const response = await fetch(
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.8-flash:generateContent",
            {
                method: "POST",

                headers: {
                    "Content-Type": "application/json",
                    "x-goog-api-key": API_KEY
                },

                body: JSON.stringify({

                    system_instruction: {
                        parts: [{
                            text:
                            "You are Talludon0 AI, a helpful and intelligent assistant. " +
                            "Give accurate, clear and detailed answers. " +
                            "Explain difficult topics simply. " +
                            "Be friendly and respectful."
                        }]
                    },

                    contents: safeContents,

                    generationConfig: {
                        temperature: 0.7,
                        maxOutputTokens: 1200
                    }

                })
            }
        );

        const data = await response.json();

        if (!response.ok) {
            return res.status(502).json({
                error: "The AI provider returned an error."
            });
        }

        const answer = data.candidates?.[0]?.content?.parts
            ?.map(part => part.text || "")
            .join("");

        if (!answer) {
            return res.status(502).json({
                error: "The AI returned no answer."
            });
        }

        return res.status(200).json({
            reply: answer
        });

    } catch (error) {

        return res.status(500).json({
            error: "Something went wrong. Please try again."
        });

    }

};